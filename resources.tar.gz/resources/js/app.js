import './bootstrap';
import './hously/plugins.init.js';
import './hously/app.js';
import "./filter.js";
import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();