

<x-navbar/>
 {{$slot}}
<x-footer/>



